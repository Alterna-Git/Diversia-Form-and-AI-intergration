/**
 * Diversia Client Onboarding — Frontend JavaScript
 * Handles multi-step form transitions, AJAX calls, and UI state management.
 */

// ---------------------------------------------------------------------------
// Global suggestion data (used by updateSuggestions() below)
// ---------------------------------------------------------------------------

var enrollmentSuggestions = {
    'obesity':             120,
    'prediabetes':         150,
    'diabetes':            200,
    'metabolic':           150,
    'cholesterol':         200,
    'thyroid':             100,
    'pcos':                 80,
    'cardiovascular':      250,
    'hypertension':        200,
    'heart-failure':       150,
    'afib':                180,
    'asthma':              150,
    'sleep-apnea':         100,
    'anxiety':             200,
    'depression':          200,
    'adhd':                150,
    'alzheimers':           50,
    'parkinsons':           60,
    'migraine':            150,
    'cognitive':            80,
    'lupus':                40,
    'arthritis':           150,
    'autoimmune':          100,
    'oncology':            200,
    'rare-cancer':          30,
    'ckd':                 150,
    'liver':               100,
    'chronic-pain':        150,
    'gerd':                100,
    'osteoporosis':        150,
    'diabetic-neuropathy': 100,
    'glaucoma':            100,
    'hiv':                 200,
    'infectious':          200,
    'rare-genetic':         25,
    'rare-pediatric':       25
};

var timelineSuggestions = {
    'obesity':              12,
    'prediabetes':          18,
    'diabetes':             24,
    'metabolic':            18,
    'cholesterol':          12,
    'thyroid':              12,
    'pcos':                 18,
    'cardiovascular':       36,
    'hypertension':         24,
    'heart-failure':        36,
    'afib':                 30,
    'asthma':               18,
    'sleep-apnea':          12,
    'anxiety':              12,
    'depression':           18,
    'adhd':                 12,
    'alzheimers':           48,
    'parkinsons':           36,
    'migraine':             12,
    'cognitive':            24,
    'lupus':                30,
    'arthritis':            24,
    'autoimmune':           24,
    'oncology':             36,
    'rare-cancer':          48,
    'ckd':                  36,
    'liver':                30,
    'chronic-pain':         18,
    'gerd':                 12,
    'osteoporosis':         24,
    'diabetic-neuropathy':  18,
    'glaucoma':             18,
    'hiv':                  36,
    'infectious':           24,
    'rare-genetic':         48,
    'rare-pediatric':       48
};

// Disease-value → LeadEngine condition key mapping (mirrors _LE.keyMap from dco-estimator.js)
var _LE_KEY_MAP = {
    'obesity':'OB',         'prediabetes':'PRE',  'diabetes':'DT2',  'metabolic':'SM',
    'cholesterol':'COL',    'thyroid':'TIR',       'pcos':'SOP',
    'cardiovascular':'CVD', 'hypertension':'HTA',  'heart-failure':'IC', 'afib':'FA',
    'asthma':'ASM',         'sleep-apnea':'APN',
    'anxiety':'ANX',        'depression':'DEP',    'adhd':'TDAH',
    'alzheimers':'ALZ',     'parkinsons':'PK',     'migraine':'MIG',  'cognitive':'DCG',
    'lupus':'LUP',          'arthritis':'ART',     'autoimmune':'AUR',
    'oncology':'ONC',       'rare-cancer':'CRH',
    'ckd':'ERC',            'liver':'HEP',         'chronic-pain':'DOL', 'gerd':'ERG',
    'osteoporosis':'OST',   'diabetic-neuropathy':'NDB', 'glaucoma':'GLC',
    'hiv':'VIH',            'infectious':'INF',
    'rare-genetic':'TGR',   'rare-pediatric':'CPR'
};

(function ($) {
    'use strict';

    // ---------------------------------------------------------------------------
    // State
    // ---------------------------------------------------------------------------
    var state = {
        applicationId: null,
        token: null,
        nonceStep2: null,
        nonceStripe: null,
        lang: 'en',
        aiReasoningEs: '',
        aiReasoningEn: '',
        aiSuggestions: [],
    };

    // ---------------------------------------------------------------------------
    // Init
    // ---------------------------------------------------------------------------
    $(document).ready(function () {
        initLangToggle();
        initStep1();
        initStep2();
        initReviseButton();
        initPayButton();
        initPasswordStrength();
        initCharCounter();
        initNewCampaignButton();
        initSuggestionWiring();

        // Revise button — delegated click handler (belt-and-suspenders alongside initReviseButton)
        $(document).on('click', '#dco-btn-revise', function () {
            goToStep(2);
        });
    });

    // ---------------------------------------------------------------------------
    // Language Toggle
    // ---------------------------------------------------------------------------
    function initLangToggle() {
        $('#dco-lang-btn').on('click', function () {
            state.lang = (state.lang === 'en') ? 'es' : 'en';
            applyLanguage(state.lang);
        });
    }

    /**
     * Swaps all [data-i18n] elements to the chosen language.
     * Also updates placeholders and select option text.
     * Also refreshes the AI reasoning block if already populated.
     */
    function applyLanguage(lang) {
        // Targets both the registration form and the payment gate (both share .dco-wrapper)
        var $wrapper = $('.dco-wrapper');
        var $btn     = $('#dco-lang-btn');

        // Toggle button visual state and label
        if (lang === 'es') {
            $btn.addClass('dco-lang-toggle--active');
        } else {
            $btn.removeClass('dco-lang-toggle--active');
        }

        // Swap all text nodes that have data-i18n
        $wrapper.find('[data-i18n]').each(function () {
            var $el  = $(this);
            var text = $el.data(lang);
            if (text !== undefined) {
                // Preserve child elements (e.g. SVG inside buttons) — only swap if element
                // is a leaf node (no child elements, only text)
                if ($el.children().length === 0) {
                    $el.text(text);
                } else {
                    // For elements with children (like buttons with icons), update only the
                    // first text node — handled by targeting specific child spans instead
                    $el.contents().filter(function () {
                        return this.nodeType === 3; // Text node
                    }).first().replaceWith(text);
                }
            }
        });

        // Swap placeholders
        $wrapper.find('[data-placeholder-' + lang + ']').each(function () {
            var placeholder = $(this).data('placeholder-' + lang);
            if (placeholder) {
                $(this).attr('placeholder', placeholder);
            }
        });

        // Swap select option text
        $wrapper.find('select option[data-i18n]').each(function () {
            var text = $(this).data(lang);
            if (text !== undefined) {
                $(this).text(text);
            }
        });

        // Refresh AI reasoning block with the correct language
        refreshReasoningBlock(lang);

        // Re-render suggestions in the active language
        if (state.aiSuggestions && state.aiSuggestions.length) {
            renderSuggestions(state.aiSuggestions, lang);
        }

        // Translate viability cards (use data-en / data-es, not data-i18n)
        $wrapper.find('.lang-text').each(function () {
            var val = $(this).data(lang);
            if (val !== undefined) { $(this).text(val); }
        });
    }

    /**
     * Updates the reasoning block (qualified or rejected) after language switch.
     */
    function refreshReasoningBlock(lang) {
        if (state.aiReasoningEs || state.aiReasoningEn) {
            var text = (lang === 'es') ? state.aiReasoningEs : state.aiReasoningEn;
            var $block = $('#dco-reasoning-qualified, #dco-reasoning-rejected').filter(':visible');
            if ($block.length && text) {
                $block.html('<p>' + escHtml(text) + '</p>');
            }
        }
    }

    // ---------------------------------------------------------------------------
    // Step 1 — Account Info
    // ---------------------------------------------------------------------------
    function initStep1() {
        $('#dco-form-step1').on('submit', function (e) {
            e.preventDefault();

            var $form = $(this);
            var $btn  = $('#dco-btn-step1');

            // Inject nonce
            $('#dco-nonce-step1').val(dcoData.nonce_step1);

            // Client-side validation
            var errors = validateStep1($form);
            if (errors.length) {
                showError(errors.join('<br>'));
                return;
            }

            hideError();
            setBtnLoading($btn, true);

            $.ajax({
                url:  dcoData.ajaxurl,
                type: 'POST',
                data: $form.serialize(),
                success: function (res) {
                    if (res.success) {
                        state.applicationId  = res.data.application_id;
                        state.nonceStep2     = res.data.nonce_step2;

                        // Populate hidden fields for step 2
                        $('#dco-app-id-step2').val(state.applicationId);
                        $('#dco-nonce-step2').val(state.nonceStep2);
                        $('#dco-application-id').val(state.applicationId);

                        goToStep(2);
                    } else {
                        var msg = (res.data && res.data.message) ? res.data.message : 'An error occurred. / Ocurrió un error.';
                        if (res.data && res.data.code === 429) {
                            showError('⏱ ' + msg);
                        } else {
                            showError(msg);
                        }
                        setBtnLoading($btn, false);
                    }
                },
                error: function () {
                    showError('Connection error. Please try again. / Error de conexión. Por favor intente de nuevo.');
                    setBtnLoading($btn, false);
                }
            });
        });

        // Back button on step 2
        $('#dco-btn-back').on('click', function () {
            hideError();
            goToStep(1);
        });
    }

    function validateStep1($form) {
        var errors = [];
        var email   = $form.find('#dco-email').val().trim();
        var pass    = $form.find('#dco-password').val();
        var confirm = $form.find('#dco-password-confirm').val();

        if (!$form.find('#dco-first-name').val().trim())    errors.push('First name / Nombre es requerido.');
        if (!$form.find('#dco-last-name').val().trim())     errors.push('Last name / Apellido es requerido.');
        if (!email)                                          errors.push('Email es requerido.');
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Invalid email / Correo electrónico inválido.');
        if (!$form.find('#dco-company').val().trim())       errors.push('Organization name / Nombre de organización es requerido.');
        if (pass.length < 8)                                 errors.push('Password must be at least 8 characters / La contraseña debe tener al menos 8 caracteres.');
        if (pass !== confirm)                                errors.push('Passwords do not match / Las contraseñas no coinciden.');

        return errors;
    }

    // ---------------------------------------------------------------------------
    // Step 2 — Trial Needs
    // ---------------------------------------------------------------------------
    function initStep2() {
        $('#dco-form-step2').on('submit', function (e) {
            e.preventDefault();

            var $form = $(this);
            var $btn  = $('#dco-btn-step2');

            var errors = validateStep2($form);
            if (errors.length) {
                showError(errors.join('<br>'));
                return;
            }

            hideError();
            setBtnLoading($btn, true);

            // Inject nonce and capture form data BEFORE hiding the panel via goToStep
            $('#dco-nonce-step2').val(state.nonceStep2 || dcoData.nonce_step2);
            var formData = $form.serialize();

            // Now show loading screen
            goToStep(3);

            $.ajax({
                url:     dcoData.ajaxurl,
                type:    'POST',
                data:    formData,
                timeout: 120000, // 120s — 3-pass AI evaluation can take 60-90s
                success: function (res) {
                    if (res.success) {
                        handleAiResult(res.data);
                    } else {
                        var msg = (res.data && res.data.message) ? res.data.message : 'Evaluation failed. / La evaluación falló.';
                        var code = (res.data && res.data.code) ? res.data.code : '';
                        console.error('[DCO] Step 2 AJAX error. Code:', code, '| Message:', msg);
                        if (code === 'api_key_missing') {
                            msg = 'The AI evaluation is not configured yet. Please contact support. / La evaluación AI no está configurada. Contacte al soporte.';
                        }
                        goToStep(2);
                        showError(msg);
                        setBtnLoading($btn, false);
                    }
                },
                error: function (xhr, status) {
                    goToStep(2);
                    if (status === 'timeout') {
                        showError('The evaluation timed out. Please try again. / La evaluación tardó demasiado.');
                    } else {
                        showError('Connection error. / Error de conexión.');
                    }
                    setBtnLoading($btn, false);
                }
            });
        });
    }

    function validateStep2($form) {
        var errors = [];

        // Resolve org type — if "Other" selected, use the text input value
        var orgType = $form.find('#dco-org-type').val();
        if (orgType === 'Other') {
            var orgOther = $form.find('#dco-org-other').val().trim();
            if (orgOther) {
                $form.find('#dco-org-type').val(orgOther);
                orgType = orgOther;
            }
        }

        // Resolve trial type — if "Other", use the text input
        var trialType = $form.find('#dco-trial-type-value').val();
        if (trialType === 'Other') {
            var trialOther = $form.find('#dco-trial-type-other').val().trim();
            if (trialOther) {
                $form.find('#dco-trial-type-value').val(trialOther);
                trialType = trialOther;
            }
        }

        var budget   = parseInt($form.find('#dco-budget').val(), 10) || 0;
        var country  = $form.find('#dco-campaign-country').val();
        var enroll   = parseInt($form.find('#dco-enrollment-goal').val(), 10) || 0;
        var timeline = parseInt($form.find('#dco-timeline').val(), 10) || 0;

        if (!trialType)         errors.push('Trial type / Tipo de ensayo es requerido.');
        if (!orgType.trim())    errors.push('Organization / Organización es requerido.');
        if (!country)           errors.push('Campaign location / Ubicación de campaña es requerida.');
        if (!budget)            errors.push('Budget / Presupuesto es requerido.');
        else if (budget < 500)  errors.push('Minimum budget is $500. / El presupuesto mínimo es $500.');
        if (!enroll)            errors.push('Enrollment goal / Meta de participantes es requerida.');
        if (!timeline)          errors.push('Timeline / Duración es requerida.');

        return errors;
    }

    // ---------------------------------------------------------------------------
    // AI Result Handler
    // ---------------------------------------------------------------------------
    function handleAiResult(data) {
        var qualified = (data.status === 'qualified');

        // Log debug info so you can see what the AI returned (open DevTools → Console)
        if (data._debug) {
            console.info('[DCO] AI raw response:', data._debug);
        }
        if (!qualified) {
            console.warn('[DCO] Application not qualified. Score:', data.score, '| Reason:', data.reasoning_en);
        }

        // Store both language versions so the toggle can refresh them
        state.aiReasoningEs = data.reasoning_es || '';
        state.aiReasoningEn = data.reasoning_en || '';

        // Show reasoning in the currently active language
        var reasoning = '<p>' + escHtml(state.lang === 'es' ? state.aiReasoningEs : state.aiReasoningEn) + '</p>';

        // Run recruitment viability analysis client-side (requires dco-estimator.js)
        _runLeViability();

        if (qualified) {
            state.token       = data.token;
            state.nonceStripe = data.nonce_stripe;

            $('#dco-token').val(state.token);
            $('#dco-reasoning-qualified').html(reasoning);
            goToStep('4a');

            // Render viability card on qualified screen
            _s2RenderLeViability('dco-le-viability-q');
        } else {
            // Store suggestions and refresh nonce for potential resubmission
            state.aiSuggestions = data.suggestions || [];
            if (data.nonce_step2) {
                state.nonceStep2 = data.nonce_step2;
                $('#dco-nonce-step2').val(state.nonceStep2);
            }

            $('#dco-reasoning-rejected').html(reasoning);
            goToStep('4b');

            // Render AI suggestions and show revise CTA
            if (state.aiSuggestions.length) {
                renderSuggestions(state.aiSuggestions, state.lang);
                $('#dco-suggestions-rejected').show();
                $('#dco-revise-cta').show();
            }

            // Render viability card on rejected screen
            _s2RenderLeViability('dco-le-viability-r');
        }
    }

    /**
     * Builds the suggestions list HTML and injects it into #dco-suggestions-list.
     * Called on first render and whenever language is toggled.
     */
    function renderSuggestions(suggestions, lang) {
        var $list = $('#dco-suggestions-list');
        if (!$list.length || !suggestions.length) return;

        var html = '';
        suggestions.forEach(function (s) {
            var issue = escHtml(lang === 'es' ? (s.issue_es || s.issue_en) : s.issue_en);
            var fix   = escHtml(lang === 'es' ? (s.suggestion_es || s.suggestion_en) : s.suggestion_en);
            html += '<li class="dco-suggestions__item">';
            html += '<p class="dco-suggestions__item-issue">' + issue + '</p>';
            html += '<p class="dco-suggestions__item-fix">' + fix + '</p>';
            html += '</li>';
        });

        $list.html(html);
    }

    // ---------------------------------------------------------------------------
    // Revise Button — Rejected screen
    // ---------------------------------------------------------------------------
    function initReviseButton() {
        $('#dco-btn-revise').on('click', function () {
            // Reset step 2 submit button in case it was left in loading state
            setBtnLoading($('#dco-btn-step2'), false);
            hideError();
            goToStep(2);
        });
    }

    // ---------------------------------------------------------------------------
    // New Campaign Button — Returning client entry screen
    // ---------------------------------------------------------------------------
    function initNewCampaignButton() {
        $('#dco-btn-new-campaign').on('click', function () {
            var $btn = $(this);
            setBtnLoading($btn, true);
            hideError();

            $.ajax({
                url:  dcoData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'dco_start_new_campaign',
                    nonce:  dcoData.nonce_new_campaign,
                },
                success: function (res) {
                    if (res.success) {
                        state.applicationId = res.data.application_id;
                        state.nonceStep2    = res.data.nonce_step2;

                        $('#dco-app-id-step2').val(state.applicationId);
                        $('#dco-nonce-step2').val(state.nonceStep2);
                        $('#dco-application-id').val(state.applicationId);

                        goToStep(2);
                    } else {
                        var msg = (res.data && res.data.message) ? res.data.message : 'Could not start campaign. Please try again.';
                        showError(msg);
                        setBtnLoading($btn, false);
                    }
                },
                error: function () {
                    showError('Connection error. Please try again. / Error de conexión.');
                    setBtnLoading($btn, false);
                }
            });
        });
    }

    // ---------------------------------------------------------------------------
    // Pay Button — Qualified screen
    // ---------------------------------------------------------------------------
    function initPayButton() {
        $('#dco-btn-pay').on('click', function () {
            var $btn = $(this);
            setBtnLoading($btn, true);
            hideError();

            $.ajax({
                url:  dcoData.ajaxurl,
                type: 'POST',
                data: {
                    action:         'dco_create_stripe_session',
                    nonce:          state.nonceStripe || dcoData.nonce_stripe,
                    application_id: state.applicationId,
                    token:          state.token,
                },
                success: function (res) {
                    if (res.success && res.data.checkout_url) {
                        window.location.href = res.data.checkout_url;
                    } else {
                        var msg = (res.data && res.data.message) ? res.data.message : 'Could not initiate payment. / No se pudo iniciar el pago.';
                        showError(msg);
                        setBtnLoading($btn, false);
                    }
                },
                error: function () {
                    showError('Connection error. Please try again. / Error de conexión.');
                    setBtnLoading($btn, false);
                }
            });
        });
    }

    // ---------------------------------------------------------------------------
    // Password Strength Indicator + Criteria Checklist
    // ---------------------------------------------------------------------------
    function initPasswordStrength() {
        $('#dco-password').on('input', function () {
            var pass     = $(this).val();
            var strength = 0;
            var $fill    = $('#dco-strength-fill');
            var $text    = $('#dco-strength-text');

            var hasLength  = pass.length >= 8;
            var hasUpper   = /[A-Z]/.test(pass);
            var hasNumber  = /[0-9]/.test(pass);
            var hasSpecial = /[^A-Za-z0-9]/.test(pass);

            if (hasLength)  strength++;
            if (hasUpper)   strength++;
            if (hasNumber)  strength++;
            if (hasSpecial) strength++;

            // Update live criteria indicators
            setCriterion('dco-crit-length',  hasLength);
            setCriterion('dco-crit-upper',   hasUpper);
            setCriterion('dco-crit-number',  hasNumber);
            setCriterion('dco-crit-special', hasSpecial);

            var colors = ['', '#e74c3c', '#f39c12', '#2ecc71', '#27ae60'];
            var labels = ['', 'Débil / Weak', 'Regular / Fair', 'Buena / Good', 'Fuerte / Strong'];

            $fill.css({ width: (strength * 25) + '%', background: colors[strength] || '' });
            $text.text(pass.length ? labels[strength] : '');
        });
    }

    function setCriterion(id, met) {
        var el = document.getElementById(id);
        if (!el) return;
        if (met) {
            el.classList.add('dco-criterion--met');
        } else {
            el.classList.remove('dco-criterion--met');
        }
    }

    // ---------------------------------------------------------------------------
    // Character Counter
    // ---------------------------------------------------------------------------
    function initCharCounter() {
        $('#dco-notes').on('input', function () {
            var len = $(this).val().length;
            $(this).siblings('.dco-char-count').text(len + ' / 1000');
        });
    }

    // ---------------------------------------------------------------------------
    // Suggestion Wiring — disease/budget/org change events
    // ---------------------------------------------------------------------------
    function initSuggestionWiring() {
        $(document).on('change', '#dco-org-type, #dco-location', updateSuggestions);
        $(document).on('input', '#dco-budget-min, #dco-budget, #dco-budget-max, #dco-enrollment-goal', updateSuggestions);
    }

    // ---------------------------------------------------------------------------
    // Step Navigation
    // ---------------------------------------------------------------------------
    function goToStep(step) {
        // Hide all panels
        $('.dco-panel').hide();

        // Update step indicators
        $('.dco-step').removeClass('dco-step--active dco-step--done');

        if (step === 1) {
            $('#dco-step-1').show();
            setStepState(1);
        } else if (step === 2) {
            $('#dco-step-2').show();
            setStepState(2);
            $('[data-step="1"]').addClass('dco-step--done');
        } else if (step === 3) {
            $('#dco-step-3').show();
            $('[data-step="1"], [data-step="2"]').addClass('dco-step--done');
            $('[data-step="3"]').addClass('dco-step--active');
        } else if (step === '4a') {
            $('#dco-step-4a').show();
            $('.dco-step').addClass('dco-step--done');
        } else if (step === '4b') {
            $('#dco-step-4b').show();
            $('.dco-step').addClass('dco-step--done');
        }

        // Scroll to top of wrapper
        var $wrapper = $('#dco-registration');
        if ($wrapper.length) {
            $('html, body').animate({ scrollTop: $wrapper.offset().top - 40 }, 300);
        }
    }

    function setStepState(active) {
        for (var i = 1; i <= 3; i++) {
            var $s = $('[data-step="' + i + '"]');
            if (i < active) {
                $s.addClass('dco-step--done').removeClass('dco-step--active');
            } else if (i === active) {
                $s.addClass('dco-step--active').removeClass('dco-step--done');
            }
        }
    }

    // ---------------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------------
    function showError(msg) {
        var $err = $('#dco-error');
        $err.html(msg).show();
        $('html, body').animate({ scrollTop: $err.offset().top - 20 }, 200);
    }

    function hideError() {
        $('#dco-error').hide().html('');
    }

    function setBtnLoading($btn, loading) {
        if (loading) {
            $btn.find('.dco-btn__text').hide();
            $btn.find('.dco-btn__spinner').show();
            $btn.prop('disabled', true);
        } else {
            $btn.find('.dco-btn__text').show();
            $btn.find('.dco-btn__spinner').hide();
            $btn.prop('disabled', false);
        }
    }

    function escHtml(str) {
        if (!str) return '';
        return $('<div>').text(str).html();
    }

})(jQuery);

/* ==========================================================================
   Step 2 — Disease dropdown, org toggle, timeline unit, media upload
   All assigned to window to guarantee global scope regardless of how WP loads the script
   ========================================================================== */

window.dcoToggleDropdown = function(wrapId) {
    var wrap = document.getElementById(wrapId);
    if (!wrap) return;
    var isOpen = wrap.classList.contains('open');
    document.querySelectorAll('.dco-custom-select.open').forEach(function(el) {
        el.classList.remove('open');
    });
    if (!isOpen) wrap.classList.add('open');
};

window.dcoSelectTrialType = function(el, labelEn, labelEs, isOther) {
    var display = document.getElementById('dco-trial-type-display');
    var hidden  = document.getElementById('dco-trial-type-value');
    var btn     = document.getElementById('dco-trial-type-btn');
    var other   = document.getElementById('dco-trial-type-other');
    var wrap    = document.getElementById('dco-trial-type-wrap');
    var langBtn = document.getElementById('dco-lang-btn');
    var lang    = (langBtn && langBtn.classList.contains('dco-lang-toggle--active')) ? 'es' : 'en';
    var label   = (lang === 'es' && labelEs) ? labelEs : labelEn;
    if (display) display.textContent = label;
    if (hidden)  hidden.value = labelEn;
    if (btn)     btn.classList.add('dco-custom-select__btn--selected');
    if (wrap)    wrap.classList.remove('open');
    if (other)   other.style.display = isOther ? 'block' : 'none';
    if (!isOther && other) other.value = '';

    // Trigger enrollment/timeline suggestions whenever disease changes
    if (typeof updateSuggestions === 'function') {
        updateSuggestions();
    }
};

window.dcoToggleOrgOther = function(sel) {
    var other = document.getElementById('dco-org-other');
    if (!other) return;
    other.style.display = (sel.value === 'Other') ? 'block' : 'none';
    if (sel.value !== 'Other') other.value = '';
};

window.dcoSetTimelineUnit = function(unit) {
    var hidden  = document.getElementById('dco-timeline-unit');
    var btnM    = document.getElementById('dco-unit-months');
    var btnW    = document.getElementById('dco-unit-weeks');
    // Legacy support: some templates still use 'dco-unit-days'
    var btnD    = document.getElementById('dco-unit-days');
    var prevUnit = hidden ? hidden.value : 'months';

    if (hidden) hidden.value = unit;
    if (btnM) btnM.classList.toggle('dco-unit-btn--active', unit === 'months');
    if (btnW) btnW.classList.toggle('dco-unit-btn--active', unit === 'weeks');
    if (btnD) btnD.classList.toggle('dco-unit-btn--active', unit === 'weeks' || unit === 'days');

    // Convert existing timeline value when switching units
    var input = document.getElementById('dco-timeline');
    if (input && input.value) {
        var val = parseFloat(input.value);
        if (!isNaN(val) && val > 0) {
            if (prevUnit === 'months' && unit === 'weeks')  { input.value = Math.round(val * 4.33); }
            if (prevUnit === 'weeks'  && unit === 'months') { input.value = Math.max(1, Math.round(val / 4.33)); }
            if (prevUnit === 'days'   && unit === 'months') { input.value = Math.max(1, Math.round(val / 30.4)); }
            if (prevUnit === 'months' && unit === 'days')   { input.value = Math.round(val * 30.4); }
        }
    }

    if (typeof updateSuggestions === 'function') {
        updateSuggestions();
    }
};

window.dcoSwitchMediaTab = function(tab, btn) {
    document.querySelectorAll('.dco-media-tab').forEach(function(t) {
        t.classList.remove('dco-media-tab--active');
    });
    if (btn) btn.classList.add('dco-media-tab--active');
    document.querySelectorAll('.dco-media-pane').forEach(function(p) {
        p.classList.remove('dco-media-pane--active');
        p.style.display = 'none';
    });
    var pane = document.getElementById('dco-pane-' + tab);
    if (pane) {
        pane.classList.add('dco-media-pane--active');
        pane.style.display = 'block';
    }
};

window.dcoPreviewImages = function(input) {
    var container = document.getElementById('dco-img-thumbs');
    if (!container) return;
    container.innerHTML = '';
    Array.from(input.files).slice(0, 10).forEach(function(file) {
        if (!file.type.startsWith('image/')) return;
        var reader = new FileReader();
        reader.onload = function(e) {
            var wrap = document.createElement('div');
            wrap.className = 'dco-media-thumb-wrap';
            var img = document.createElement('img');
            img.className = 'dco-media-thumb';
            img.src = e.target.result;
            var rm = document.createElement('button');
            rm.type = 'button';
            rm.className = 'dco-media-thumb-rm';
            rm.textContent = '×';
            rm.onclick = function() { wrap.remove(); };
            wrap.appendChild(img);
            wrap.appendChild(rm);
            container.appendChild(wrap);
        };
        reader.readAsDataURL(file);
    });
};

window.dcoAddVideoRow = function() {
    var list = document.getElementById('dco-video-url-list');
    if (!list) return;
    var row = document.createElement('div');
    row.className = 'dco-video-row';
    row.innerHTML = '<input class="dco-input" type="url" name="promo_video_urls[]"'
        + ' placeholder="https://youtube.com/watch?v=... or https://vimeo.com/...">'
        + '<button type="button" class="dco-video-remove" onclick="window.dcoRemoveVideoRow(this)" title="Remove">✕</button>';
    list.appendChild(row);
};

window.dcoRemoveVideoRow = function(btn) {
    var row = btn.closest('.dco-video-row');
    var list = document.getElementById('dco-video-url-list');
    if (list && list.querySelectorAll('.dco-video-row').length > 1) {
        row.remove();
    } else {
        row.querySelector('input').value = '';
    }
};

window.dcoPreviewVideos = function(input) {
    var container = document.getElementById('dco-video-file-list');
    if (!container) return;
    container.innerHTML = '';
    Array.from(input.files).forEach(function(file) {
        var size = file.size > 1048576
            ? (file.size / 1048576).toFixed(1) + ' MB'
            : (file.size / 1024).toFixed(0) + ' KB';
        var item = document.createElement('div');
        item.className = 'dco-video-file-item';
        item.innerHTML = '<span class="dco-video-file-item__icon">'
            + '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>'
            + '</span>'
            + '<div class="dco-video-file-item__info">'
            +   '<div class="dco-video-file-item__name">' + file.name + '</div>'
            +   '<div class="dco-video-file-item__size">' + size + '</div>'
            + '</div>'
            + '<button type="button" class="dco-video-file-item__rm" onclick="this.closest(\'.dco-video-file-item\').remove()">×</button>';
        container.appendChild(item);
    });
};

// ── Campaign Location — region data + dynamic checkboxes ─────────────────────
var DCO_REGIONS = {
    US: ['Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming','Washington D.C.'],
    MX: ['Aguascalientes','Baja California','Baja California Sur','Campeche','Chiapas','Chihuahua','Coahuila','Colima','Ciudad de México','Durango','Guanajuato','Guerrero','Hidalgo','Jalisco','México','Michoacán','Morelos','Nayarit','Nuevo León','Oaxaca','Puebla','Querétaro','Quintana Roo','San Luis Potosí','Sinaloa','Sonora','Tabasco','Tamaulipas','Tlaxcala','Veracruz','Yucatán','Zacatecas'],
    CO: ['Amazonas','Antioquia','Arauca','Atlántico','Bogotá D.C.','Bolívar','Boyacá','Caldas','Caquetá','Casanare','Cauca','Cesar','Chocó','Córdoba','Cundinamarca','Guainía','Guaviare','Huila','La Guajira','Magdalena','Meta','Nariño','Norte de Santander','Putumayo','Quindío','Risaralda','San Andrés y Providencia','Santander','Sucre','Tolima','Valle del Cauca','Vaupés','Vichada'],
    AR: ['Buenos Aires','Catamarca','Chaco','Chubut','Ciudad de Buenos Aires','Córdoba','Corrientes','Entre Ríos','Formosa','Jujuy','La Pampa','La Rioja','Mendoza','Misiones','Neuquén','Río Negro','Salta','San Juan','San Luis','Santa Cruz','Santa Fe','Santiago del Estero','Tierra del Fuego','Tucumán'],
    ES: ['Andalucía','Aragón','Asturias','Baleares','Canarias','Cantabria','Castilla-La Mancha','Castilla y León','Cataluña','Extremadura','Galicia','La Rioja','Madrid','Murcia','Navarra','País Vasco','Valencia']
};

window.dcoUpdateCampaignRegions = function(countryCode) {
    var other   = document.getElementById('dco-campaign-country-other');
    var locWrap = document.getElementById('dco-location-wrap');

    if (other)   other.style.display   = 'none';
    if (locWrap) locWrap.style.display = 'none';

    if (!countryCode) return;

    // Show state dropdown only for US
    if (countryCode === 'US' && locWrap) {
        locWrap.style.display = '';
    }
};

// Password peek toggle
window.dcoPeekToggle = function(inputId, btnId) {
    var input = document.getElementById(inputId);
    var btn   = document.getElementById(btnId);
    if (!input || !btn) return;
    var show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    var iconShow = btn.querySelector('.dco-peek-icon--show');
    var iconHide = btn.querySelector('.dco-peek-icon--hide');
    if (iconShow) iconShow.style.display = show ? 'none' : '';
    if (iconHide) iconHide.style.display = show ? ''     : 'none';
};

// ── Enrollment & Timeline Suggestion Engine ───────────────────────────────────

/**
 * updateSuggestions()
 * Called whenever disease, budget, or org type changes.
 * Reads current Step 2 field values and updates #dco-enrollment-hint
 * and #dco-timeline-hint with smart recommendations.
 */
// Map full English labels → internal suggestion keys
var _LABEL_TO_KEY = {
    'Obesity / Overweight':'obesity', 'Prediabetes':'prediabetes', 'Type 2 Diabetes':'diabetes',
    'Metabolic Syndrome':'metabolic', 'High Cholesterol':'cholesterol',
    'Thyroid Disease / Hypothyroidism':'thyroid', 'PCOS (Polycystic Ovary Syndrome)':'pcos',
    'Cardiovascular Disease (CVD)':'cardiovascular', 'Hypertension':'hypertension',
    'Heart Failure':'heart-failure', 'Atrial Fibrillation':'afib', 'Asthma / COPD':'asthma',
    'Sleep Apnea':'sleep-apnea', 'Anxiety':'anxiety', 'Depression':'depression', 'ADHD':'adhd',
    "Alzheimer's / Dementia":'alzheimers', "Parkinson's Disease":'parkinsons',
    'Migraine':'migraine', "Cognitive Impairment (non-Alzheimer's)":'cognitive',
    'Lupus / SLE':'lupus', 'Arthritis':'arthritis', 'Autoimmune / Rheumatology (Other)':'autoimmune',
    'Oncology / Cancer':'oncology', 'Rare Cancer / Hematology':'rare-cancer',
    'Chronic Kidney Disease (CKD)':'ckd', 'Liver Disease':'liver', 'Chronic Pain':'chronic-pain',
    'GERD / Acid Reflux':'gerd', 'Osteoporosis':'osteoporosis',
    'Diabetic Neuropathy':'diabetic-neuropathy', 'Glaucoma / Cataracts':'glaucoma',
    'HIV / AIDS':'hiv', 'Infectious Disease (Other)':'infectious',
    'Rare Genetic Disorders':'rare-genetic', 'Rare Pediatric Conditions':'rare-pediatric'
};

function updateSuggestions() {
    var rawLabel  = (document.getElementById('dco-trial-type-value') || {}).value || '';
    var diseaseKey = _LABEL_TO_KEY[rawLabel] || '';
    if (!diseaseKey || !enrollmentSuggestions[diseaseKey]) return;

    var lang = (document.getElementById('dco-lang-btn') &&
                document.getElementById('dco-lang-btn').classList.contains('dco-lang-toggle--active'))
        ? 'es' : 'en';

    // Budget multiplier (based on min budget field; fall back to single budget field)
    var budgetMinEl = document.getElementById('dco-budget-min') || document.getElementById('dco-budget');
    var budgetMin = parseFloat(budgetMinEl ? budgetMinEl.value : 0) || 0;
    var budgetMult;
    if      (budgetMin < 1000)   { budgetMult = 0.50; }
    else if (budgetMin < 5000)   { budgetMult = 0.70; }
    else if (budgetMin < 20000)  { budgetMult = 0.85; }
    else if (budgetMin < 100000) { budgetMult = 1.00; }
    else                         { budgetMult = 1.30; }

    // Org multipliers
    var orgSel = document.getElementById('dco-org-type');
    var orgVal = orgSel ? orgSel.value.toLowerCase() : '';
    var orgEnrollMult = { researcher: 0.70, cro: 1.00, university: 0.85, pharmaceutical: 1.20 }[orgVal] || 1.00;
    var orgTimeMult   = { researcher: 0.80, cro: 1.00, university: 1.20, pharmaceutical: 1.20 }[orgVal] || 1.00;

    // --- Enrollment hint ---
    var baseEnroll = enrollmentSuggestions[diseaseKey];
    if (baseEnroll) {
        var suggestedEnroll = Math.max(5, Math.round(baseEnroll * budgetMult * orgEnrollMult));
        var hintEnroll = document.getElementById('dco-enrollment-hint');
        if (hintEnroll) {
            hintEnroll.textContent = lang === 'es'
                ? 'Sugerido: ~' + suggestedEnroll + ' participantes para ' + diseaseKey
                : 'Suggested: ~' + suggestedEnroll + ' participants for ' + diseaseKey;
            hintEnroll.style.display = 'block';
        }
    }

    // --- Timeline hint ---
    var baseMonths = timelineSuggestions[diseaseKey];
    if (baseMonths) {
        var suggestedMonths = Math.max(1, Math.round(baseMonths * orgTimeMult));
        var timeUnitEl = document.getElementById('dco-timeline-unit');
        var currentUnit = timeUnitEl ? timeUnitEl.value : 'months';
        var displayVal  = (currentUnit === 'weeks') ? Math.round(suggestedMonths * 4.33) : suggestedMonths;
        var unitLabel;
        if (currentUnit === 'weeks') {
            unitLabel = (lang === 'es') ? 'semanas' : 'weeks';
        } else {
            unitLabel = (lang === 'es') ? 'meses' : 'months';
        }
        var hintTimeline = document.getElementById('dco-timeline-hint');
        if (hintTimeline) {
            hintTimeline.textContent = lang === 'es'
                ? 'Sugerido: ~' + displayVal + ' ' + unitLabel + ' para ' + diseaseKey
                : 'Suggested: ~' + displayVal + ' ' + unitLabel + ' for ' + diseaseKey;
            hintTimeline.style.display = 'block';
        }
    }
}

/**
 * dcoTimelineAutoConvert(input)
 * oninput handler for the timeline field.
 * - Clears values < 1.
 * - Auto-converts weeks >= 4 to months and switches the unit toggle.
 */
window.dcoTimelineAutoConvert = function(input) {
    var v = parseInt(input.value, 10);
    if (isNaN(v) || v < 1) { input.value = ''; return; }
    // Strip decimals
    if (v !== parseFloat(input.value)) { input.value = v; }

    var unitEl = document.getElementById('dco-timeline-unit');
    var currentUnit = unitEl ? unitEl.value : 'months';

    if (currentUnit === 'weeks' && v >= 4) {
        input.value = Math.round(v / 4.33);
        window.dcoSetTimelineUnit('months');
    } else {
        if (typeof updateSuggestions === 'function') {
            updateSuggestions();
        }
    }
};

/**
 * _runLeViability()
 * Internal — runs the LeadEngine viability analysis after AI evaluation
 * and stores the result in window._s2LeResult.
 * Requires window._leAnalyze and window._EL (from dco-estimator.js).
 */
function _runLeViability() {
    window._s2LeResult = null;

    if (typeof window._leAnalyze !== 'function' || typeof window._EL === 'undefined') {
        return;
    }

    try {
        var diseaseKey = (document.getElementById('dco-trial-type-value') || {}).value || '';
        // Use _LE_KEY_MAP (global above) or fall back to window._LE.keyMap if estimator loaded first
        var keyMap  = (window._LE && window._LE.keyMap) ? window._LE.keyMap : _LE_KEY_MAP;
        var leKey   = keyMap[diseaseKey] || null;
        var budget  = parseInt((document.getElementById('dco-budget-min') || document.getElementById('dco-budget') || {}).value) || 0;
        var enrollGoal = parseInt((document.getElementById('dco-enrollment-goal') || {}).value) || 0;
        var locCode = (document.getElementById('dco-location') || {}).value || '';

        if (!leKey || budget <= 0 || enrollGoal <= 0) { return; }

        var tlInput  = document.getElementById('dco-timeline');
        var tlUnitEl = document.getElementById('dco-timeline-unit');
        var tlVal    = parseInt(tlInput ? tlInput.value : 12) || 12;
        var tlUnit   = tlUnitEl ? tlUnitEl.value : 'months';
        var tlWeeks  = (tlUnit === 'weeks') ? tlVal : Math.round(tlVal * 4.33);

        var locs = (window._EL && window._EL[locCode]) ? [locCode] : ['CA', 'TX', 'FL', 'NY', 'AZ'];

        window._s2LeResult = window._leAnalyze({
            conditionKey:    leKey,
            locations:       locs,
            budget:          budget,
            targetEnrolled:  enrollGoal,
            timeWeeks:       Math.max(1, tlWeeks)
        });
    } catch(e) {
        window._s2LeResult = null;
    }
}

/**
 * _s2RenderLeViability(targetId)
 * Renders the recruitment viability card inside element #targetId.
 * Uses window._s2LeResult (set by _runLeViability above).
 */
function _s2RenderLeViability(targetId) {
    var el = document.getElementById(targetId);
    if (!el) return;
    var le = window._s2LeResult;
    if (!le) { el.style.display = 'none'; return; }

    function _esc(s) {
        return String(s || '')
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    var verdictClass = le.verdict === 'APROBADO'       ? 's2-le-verdict--ok'
                     : le.verdict === 'NO VIABLE'      ? 's2-le-verdict--no'
                     : 's2-le-verdict--adj';
    var verdictIcon  = le.verdict === 'APROBADO' ? '✓' : le.verdict === 'NO VIABLE' ? '✗' : '⚠';
    var verdictEn    = le.verdict === 'APROBADO'  ? 'APPROVED'
                     : le.verdict === 'NO VIABLE' ? 'NOT VIABLE'
                     : 'VIABLE WITH ADJUSTMENTS';
    var verdictEs    = le.verdict === 'APROBADO'  ? 'APROBADO'
                     : le.verdict === 'NO VIABLE' ? 'NO VIABLE'
                     : 'VIABLE CON AJUSTES';
    var locNames = le.locations.map(function(l) { return l.n; }).join(', ');
    var scen     = le.scenarios.realista;
    var topHint  = le.hints.find(function(h) { return h.priority === 'alta'; });

    el.innerHTML = '<div class="s2-le-card">'
        + '<div class="s2-le-card__header">'
        +   '<span class="s2-le-card__icon">&#128300;</span>'
        +   '<span class="s2-le-card__title lang-text"'
        +     ' data-en="Recruitment Estimator — Latino Community Viability"'
        +     ' data-es="Estimador de Reclutamiento — Viabilidad en la Comunidad Latina">'
        +     'Recruitment Estimator — Latino Community Viability'
        +   '</span>'
        + '</div>'
        + '<div class="s2-le-verdict ' + verdictClass + '">'
        +   '<span class="lang-text"'
        +     ' data-en="' + verdictIcon + ' ' + _esc(verdictEn) + '"'
        +     ' data-es="' + verdictIcon + ' ' + _esc(verdictEs) + '">'
        +     verdictIcon + ' ' + verdictEn
        +   '</span>'
        + '</div>'
        + '<div class="s2-le-metrics">'
        +   '<div class="s2-le-metric">'
        +     '<div class="s2-le-metric__val">' + le.population.pool.toLocaleString() + '</div>'
        +     '<div class="s2-le-metric__lbl lang-text"'
        +       ' data-en="Reachable Latinos &middot; ' + _esc(locNames) + '"'
        +       ' data-es="Latinos Alcanzables &middot; ' + _esc(locNames) + '">'
        +       'Reachable Latinos &middot; ' + _esc(locNames)
        +     '</div>'
        +   '</div>'
        +   '<div class="s2-le-metric">'
        +     '<div class="s2-le-metric__val">$' + scen.cpl + '</div>'
        +     '<div class="s2-le-metric__lbl lang-text" data-en="Realistic CPL" data-es="CPL Realista">Realistic CPL</div>'
        +   '</div>'
        +   '<div class="s2-le-metric">'
        +     '<div class="s2-le-metric__val">~' + scen.enrolled + '</div>'
        +     '<div class="s2-le-metric__lbl lang-text" data-en="Projected Enrolled" data-es="Participantes Proyectados">Projected Enrolled</div>'
        +   '</div>'
        + '</div>'
        + (topHint
            ? '<div class="s2-le-hint">&#128161; <strong>' + _esc(topHint.title) + ':</strong> ' + _esc(topHint.desc) + '</div>'
            : '')
        + '</div>';

    el.style.display = 'block';

    // If the wrapper is already in Spanish when the card renders, apply translations immediately
    var wrapper = el.closest('.dco-wrapper');
    if (wrapper && wrapper.dataset && wrapper.dataset.lang === 'es') {
        el.querySelectorAll('.lang-text').forEach(function(t) {
            if (t.dataset.es !== undefined) { t.textContent = t.dataset.es; }
        });
    }
}

// Close dropdown on outside click — runs after DOM ready
document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.dco-custom-select')) {
            document.querySelectorAll('.dco-custom-select.open').forEach(function(el) {
                el.classList.remove('open');
            });
        }
    });

    // Force-hide inactive media panes on load (belt-and-suspenders vs theme overrides)
    document.querySelectorAll('.dco-media-pane:not(.dco-media-pane--active)').forEach(function(p) {
        p.style.display = 'none';
    });
});
